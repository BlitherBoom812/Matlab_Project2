clear;
close all;
clc;
test_mat = logical([
    1, 1, 0, 0, 1;
    0, 1, 1, 0, 0;
    1, 0, 0, 1, 0;
    1, 1, 1, 1, 0;
    ]);

get_all_squares(test_mat)

