

function Q = quantify_block(block, quantify)
    Q = round(block ./ quantify);
end