

function Q = quantify_block_inv(block, quantify)
    Q = block .* quantify;
end