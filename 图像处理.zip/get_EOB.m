
function EOB = get_EOB()
    EOB = [1, 0, 1, 0];
end